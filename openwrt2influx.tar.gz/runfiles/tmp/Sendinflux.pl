#!/usr/bin/perl
#use strict;
use warnings;

my $rec = `/sbin/ifconfig -a | grep "HWaddr"`;
my ($field1, $field2, $field3, $field4, $mac) = split(/\s+/, $rec);
$mac =~ tr/:/-/;
`/tmp/runfiles/./cp-csv`;
@files = <*>;
 foreach $file (@files) {
  if($file =~ m/\.csv/) {
    @filename = split('\.', $file);
    $name = $filename[0];
#print "$name.csv";    
 `/runfiles/tmp/awk-csv -f $name.csv`;   
#$names=${name%-2*};
#print "$names";    
      `/tmp/runfiles/CSV/./csv-to-influxdb --batch-size=1 --server=http://192.168.1.141:8086 --database=$mac --measurement=$name /tmp/runfiles/CSV/$name.csv `;
  }
}
print "\ndone :)";
